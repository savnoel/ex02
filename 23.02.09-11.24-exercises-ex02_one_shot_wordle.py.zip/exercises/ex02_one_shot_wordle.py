"""One Shot Wordle!"""

__author__ = "730604481"

SECRET: str = "python"
GREEN_BOX: str = "\U0001F7E9"
WHITE_BOX: str = "\U00002B1C"
YELLOW_BOX: str = "\U0001F7E8"
ind: int = 0
store: str = ""

wordle: str = input(f"What is your {len(SECRET)} letter guess? ")

while len(wordle) != len(SECRET):  # Wordle is not Secret word length!
    wordle = input(f"That was not {len(SECRET)} letters! Try again: ")

if SECRET == wordle:  # Wordle is secret word
    print("Woo! You got it!")
else:  # wordle is not secret word
    print("Not quite. Play again soon!")

while ind < len(SECRET):  # while the indexes of secret is less than the length of secret (indexes = length-1)
    if wordle[ind] == SECRET[ind]:
        store = store + GREEN_BOX
    else:
        existing: bool = False
        exist_anywhere: int = 0
        while existing is not True and exist_anywhere < len(SECRET): 
            if (SECRET[exist_anywhere]) == (wordle[ind]):  # While existing is false and the alternate index of secret is = to ind of guess
                existing = True 
            else:  # If existing is False
                exist_anywhere = exist_anywhere + 1
        if existing is True:   # if existing is true
            store = store + YELLOW_BOX
        else:   # If existing is false
            store = store + WHITE_BOX
    ind = ind + 1   # To loop around until ind < len(SECRET)
print(store)
 

  